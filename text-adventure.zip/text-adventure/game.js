const storyElement = document.getElementById("story");
const choicesElement = document.getElementById("choices");

let state = {};

function startGame() {
  state = {};
  showNode(1);
}

function showNode(nodeIndex) {
  const node = storyNodes.find(n => n.id === nodeIndex);
  storyElement.innerText = node.text;

  choicesElement.innerHTML = '';
  node.options.forEach(option => {
    const button = document.createElement('button');
    button.innerText = option.text;
    button.onclick = () => selectOption(option);
    choicesElement.appendChild(button);
  });
}

function selectOption(option) {
  const nextNodeId = option.nextText;
  if (nextNodeId <= 0) {
    return startGame();
  }
  showNode(nextNodeId);
}

const storyNodes = [
  {
    id: 1,
    text: 'You wake up in a dark forest. There’s a path ahead and a river nearby.',
    options: [
      { text: 'Follow the path', nextText: 2 },
      { text: 'Go to the river', nextText: 3 }
    ]
  },
  {
    id: 2,
    text: 'You find a clearing with a small hut.',
    options: [
      { text: 'Enter the hut', nextText: 4 },
      { text: 'Go back', nextText: 1 }
    ]
  },
  {
    id: 3,
    text: 'The river is fast and deep. Something glints under the water.',
    options: [
      { text: 'Reach for the glint', nextText: 5 },
      { text: 'Go back', nextText: 1 }
    ]
  },
  {
    id: 4,
    text: 'Inside the hut, you find a sword and a note saying "Beware the shadows."',
    options: [
      { text: 'Take the sword and continue', nextText: 6 }
    ]
  },
  {
    id: 5,
    text: 'A tentacled creature drags you under. You are lost to the depths.',
    options: [
      { text: 'Restart', nextText: -1 }
    ]
  },
  {
    id: 6,
    text: 'Armed with the sword, you feel ready to face the forest’s dangers.',
    options: [
      { text: 'Onward!', nextText: -1 }
    ]
  }
];

startGame();